# Your own Farcaster server

Test build. The complete installer still needs a fresh, independent trial. No prizes or income are promised.

## Windows11 x64

You need Node.js24, current WSL2, 4 CPU cores, 16GBRAM available to Linux, 2TBfree on the selected disk and reliable internet. 32GBtotal RAM is preferable on Windows. Official downloads: https://nodejs.org/ and https://learn.microsoft.com/windows/wsl/install . Windows may require administrator approval or a restart. This kit does not change global WSL memory settings.

1. Extract the whole ZIP into a normal folder. Open Start.cmd.
2. Enter a NEW data folder, for example D:\FarcasterNode. Open the local setup address it shows.
3. Review the folder and permission, then press Set up server. When ready, press Open the app.

Leave the terminal and computer running. First it downloads, then unpacks, then catches up. It may take many hours. If a step fails, read Details and retry the same setup. Existing data stays in place. The kit never deletes a node or changes your firewall.

## Three commands instead

Use PowerShell after extracting the source into C:\FarcasterQuickstart. Choose your actual data drive; D: below is an example.

```powershell
# Source / context:
# Farcaster test build, extracted source
cd "C:\FarcasterQuickstart"

# Commands:
node scripts/quickstart.mjs computer --data "D:\FarcasterNode" --install
node scripts/quickstart.mjs node --start
node scripts/quickstart.mjs app
```

The first command prepares a separate Ubuntu24.04 environment and Docker. The second starts or resumes the same node. The third starts the local app. Add --plan instead of --install/--start to inspect the first two stages without changes.

## Linux

Ubuntu24.04 x64 and Node.js24 are the supported candidate. Use the same three commands, with an absolute data folder on the intended disk, for example /mnt/data/farcaster. The parent disk/folder must already exist. The computer step may ask for sudo to install official Docker packages. If Docker needs administrator access, use sudo -v in your terminal before the node step. No cloud machine is ordered and no global user-group permission is changed.

## Optional posting test

Reading needs no wallet. Posting needs a separate Farcaster account that is registered, has storage, and is controlled by a compatible browser wallet (MetaMask). Phone-only signing is not implemented here. Never paste recovery phrases into this app, chat or logs. Account signup/storage may have a separate cost.

Close the local app terminal before changing its test account. Replace123 and456 below:123 is YOUR SEPARATE TEST ACCOUNT number;456 is the DIFFERENT account you choose to follow publicly. Do not use your main account as the test author. After configuring, run app again.

```powershell
# Source / context:
# Farcaster test build; use public account numbers only
cd "C:\FarcasterQuickstart"

# Commands:
node scripts/quickstart.mjs account --fid 123 --follow 456 --confirm-test-account
node scripts/quickstart.mjs app
```

Open http://127.0.0.1:3423/. Review two gasless wallet signatures for a limited app key. The key can post/remove posts, follow/unfollow and add/remove reactions. It expires after24hours of inactivity, renewed on use. Each public test still needs your approval in the app. The like test uses your own test post. Then undo the tests and revoke access. Verify the exact results; a submission receipt alone is not proof. It cannot move money or authorize another app key.

The local key stays in runtime/test-accounts/<FID>/. Do not share that folder. Changing account configuration never erases another account's receipts or revocation record.

## Checking and resuming

Run node scripts/quickstart.mjs status to see the container and recent logs. After Windows restarts, run the node command again, then app. Use the same extracted source folder and data folder. Do not move or delete runtime/quickstart-install.json: it identifies the owned installation.

## What this is

A read node stores and updates Farcaster data. An app reads it; approved signed actions go through the node to validators. An account number is an FID. Its custody wallet controls it; a limited app key acts with permission. Account storage rent and server hosting are different costs. Our HTTP/RPC ports stay on localhost; this is not a public shared API or validator.

The app can include/hide posts by the account that registered a posting key, within the latest20posts. Unknown origins stay labelled; that origin is not proof of which screen composed the post.

The original wrapper is MIT. Snapchain is GPLv3; its separate license and exact pinned source are downloaded during preparation. No auto-upgrades, paid cloud resources, public posts or network exposure are enabled by default.

Bounty: https://farcaster.xyz/balajis.eth/0x50184b62 . Correction: https://farcaster.xyz/balajis.eth/0x0a05d5c8 . Qualification still requires an independent person to install successfully and voluntarily endorse it. This test build is not evidence of that outcome.
