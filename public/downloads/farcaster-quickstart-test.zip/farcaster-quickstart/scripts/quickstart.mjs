import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync,spawn} from 'node:child_process';
import {createHash,randomBytes} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {windowsPlan,resourceCheck,resumeDecision,accountSettings,parseArguments,decodeOutput} from './quickstart-core.mjs';
import {makePlan,sourceRevision,image,composeOverride} from './setup-plan.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),runtime=path.join(root,'runtime');
const record=path.join(runtime,'quickstart-install.json');
const digest=s=>createHash('sha256').update(s).digest('hex');
function exec(command,args,options={}){
  const r=spawnSync(command,args,{timeout:20000,maxBuffer:4e6,windowsHide:true,...options});
  if(r.status!==0)throw Error((decodeOutput(r.stderr)||decodeOutput(r.stdout)||r.error?.message||'Command failed').slice(-1800));
  return decodeOutput(r.stdout);
}
function command(plan,program,args=[],options={}){
  return plan.backend==='wsl'?exec('wsl.exe',['-d',plan.distro,'-u','root','--exec',program,...args],options):exec(program,args,options);
}
function docker(plan,args,options={}){
  try{return command(plan,'docker',args,options);}catch(e){
    if(plan.backend==='linux'&&/permission denied/i.test(e.message))return exec('sudo',['-n','docker',...args],options);
    throw e;
  }
}
function compose(plan){return ['compose','--project-name',plan.project,'--project-directory',plan.directory,'-f',plan.directory+'/compose.upstream.yml','-f',plan.directory+'/compose.local.yml'];}
function save(p){fs.mkdirSync(runtime,{recursive:true});fs.writeFileSync(record,JSON.stringify(p,null,2),{mode:0o600});}
function load(){
  if(!fs.existsSync(record))throw Error('Run computer first. No installation record exists.');
  const p=JSON.parse(fs.readFileSync(record,'utf8'));
  if((p.backend==='wsl'&&process.platform!=='win32')||(p.backend==='linux'&&process.platform!=='linux'))throw Error('This installation record belongs to another operating system.');
  if(p.image!==image||p.sourceRevision!==sourceRevision||p.project!=='farcaster-quickstart')throw Error('Installation versions changed. Review before proceeding.');
  if(p.backend==='wsl'){
    const expected=windowsPlan(p.data);
    if(p.distro!==expected.distro||p.directory!==expected.directory)throw Error('Installation path changed.');
  }else if(p.backend!=='linux'||makePlan(p.directory).directory!==p.directory)throw Error('Invalid installation path.');
  return p;
}
function hostResources(data,resume=false){
  if(!fs.existsSync(data)&&!fs.existsSync(path.dirname(data)))throw Error('The parent data folder is missing. Mount or choose the intended drive first.');
  let disk=data;while(!fs.existsSync(disk)){const parent=path.dirname(disk);if(parent===disk)throw Error('Selected drive does not exist.');disk=parent;}
  const s=fs.statfsSync(disk),result=resourceCheck({cpus:os.cpus().length,memory:os.totalmem(),free:s.bavail*s.bsize},resume);
  if(!result.ready)throw Error(result.checks.filter(c=>!c.ok).map(c=>c.name).join('; ')+'. No installation started.');
}
function engineResources(p,resume=false){
  const engine=JSON.parse(docker(p,['info','--format','{{json .}}']));
  const free=Number(command(p,'df',['-B1','--output=avail',p.directory]).split(/\s+/).at(-1));
  const s=resourceCheck({cpus:engine.NCPU,memory:engine.MemTotal,free},resume);
  if(!s.ready)throw Error(s.checks.filter(c=>!c.ok).map(c=>c.name).join('; ')+'. Check Docker/WSL allocation; this installer does not change global WSL settings.');
  const [major,minor]=docker(p,['compose','version','--short']).replace(/^v/,'').split('.').map(Number);
  if(!(major>2||(major===2&&minor>=24)))throw Error('Docker Compose2.24 or newer is required.');
}
function writeLinux(p,name,body){
  if(p.backend==='wsl')command(p,'sh',['-c','umask 077; cat > "$1"','sh',p.directory+'/'+name],{input:body});
  else fs.writeFileSync(p.directory+'/'+name,body,{mode:0o600});
}
async function pinnedFiles(p){
  const fetched=await Promise.all(['docker-compose.mainnet.yml','validators.toml','LICENSE'].map(async name=>{
    const r=await fetch(`https://raw.githubusercontent.com/farcasterxyz/snapchain/${sourceRevision}/${name}`,{signal:AbortSignal.timeout(20000)});
    if(!r.ok)throw Error('Could not fetch the pinned Snapchain source. Retry computer; no snapshot has started.');return await r.text();
  }));
  const files={'compose.upstream.yml':fetched[0],'validators.toml':fetched[1],'LICENSE.upstream':fetched[2],'compose.local.yml':composeOverride()};
  for(const [name,body]of Object.entries(files))writeLinux(p,name,body);
  p.files=Object.fromEntries(Object.entries(files).map(([name,body])=>[name,digest(body)]));
  docker(p,[...compose(p),'config','--quiet']);
}
function verifyFiles(p){
  if(!p.files||Object.keys(p.files).length!==4)throw Error('Computer preparation is incomplete. Retry that step.');
  for(const [name,hash]of Object.entries(p.files)){
    if(!['compose.upstream.yml','validators.toml','LICENSE.upstream','compose.local.yml'].includes(name))throw Error('Unexpected installation file.');
    const actual=command(p,'sha256sum',[p.directory+'/'+name]).split(/\s+/)[0];
    if(actual!==hash)throw Error('Prepared files changed. Inspect before restarting.');
  }
}
function ownContainer(p){
  const ids=docker(p,['ps','-aq','--filter','label=com.docker.compose.project='+p.project]).split(/\s+/).filter(Boolean);
  if(ids.length>1)throw Error('Multiple containers found. Inspect before resuming.');
  return ids.length?JSON.parse(docker(p,['inspect',ids[0]]))[0]:null;
}
function keepWslAlive(p,c){
  if(p.backend!=='wsl')return;
  const marker=path.join(runtime,'quickstart-worker.json');
  // Check only this dedicated distro; a saved Windows PID can be recycled after reboot.
  try{command(p,'pgrep',['-f','^docker attach --sig-proxy=false '+c.Id+'$']);return;}catch{}
  const output=fs.openSync(path.join(runtime,'quickstart-node.log'),'a');
  const worker=spawn('wsl.exe',['-d',p.distro,'-u','root','--exec','docker','attach','--sig-proxy=false',c.Id],{stdio:['ignore',output,output],detached:true,windowsHide:true});
  worker.unref();fs.closeSync(output);fs.writeFileSync(marker,JSON.stringify({pid:worker.pid,container:c.Id}));
}
async function computer(options){
  if(!options.data)throw Error('Choose the data folder with --data.');
  let p=process.platform==='win32'?windowsPlan(options.data):{...makePlan(options.data),backend:'linux',data:options.data};
  p={...p,image,sourceRevision};
  if(options.plan)return console.log(JSON.stringify({...p,changes:'None. Add --install after reviewing.',stages:['Check disk and resources','Prepare Ubuntu and Docker','Write pinned node configuration']},null,2));
  if(!options.install)throw Error('This installs software. Review with --plan first, then add --install.');
  if(process.arch!=='x64')throw Error('This installer supports x64 only.');
  let saved;
  if(fs.existsSync(record)){saved=load();if(saved.data!==p.data||saved.backend!==p.backend)throw Error('A different installation is recorded. Use that folder; nothing changed.');p=saved;}
  hostResources(p.data,!!saved?.prepared);
  if(p.backend==='wsl'){
    const help=exec('wsl.exe',['--help']);
    if(!['--location','--name','--vhd-size'].every(flag=>help.includes(flag)))throw Error('Update WSL from Microsoft first. Windows may require administrator approval and a restart.');
    const distros=exec('wsl.exe',['--list','--quiet']).split(/[\r\n]+/).filter(Boolean);
    if(distros.includes(p.distro)&&!saved)throw Error('FarcasterQuickstart already exists without our record. No existing distro will be adopted.');
    if(!distros.includes(p.distro)){
      if(fs.existsSync(p.data))throw Error('The selected folder already exists. Choose a new folder.');
      save(p); // Retain recovery information before a long Windows operation.
      console.log('Preparing the dedicated Ubuntu environment. Windows may request approval.');
      exec('wsl.exe',p.installArgs,{timeout:600000,stdio:'inherit'});
      exec('wsl.exe',['--set-version',p.distro,'2'],{timeout:600000,stdio:'inherit'});
    }
    command(p,'install',['-d','-m','700',p.directory]);
    command(p,'bash',['-s','--','--install'],{input:fs.readFileSync(path.join(root,'scripts/provision-ubuntu.sh'),'utf8').replaceAll('\r\n','\n'),timeout:600000,stdio:['pipe','inherit','inherit']});
  }else{
    if(fs.existsSync(p.directory)&&!saved)throw Error('The data folder exists. Choose a new folder.');
    if(!fs.existsSync(p.directory))fs.mkdirSync(p.directory,{mode:0o700});
    if(fs.realpathSync(p.directory)!==p.directory)throw Error('Choose the actual data directory, not a symlink.');
    save(p);
    let existingEngine=false;try{docker(p,['info','--format','{{json .}}']);existingEngine=true;}catch{}
    if(!existingEngine){
      const cmd=process.getuid?.()===0?'bash':'sudo';
      exec(cmd,process.getuid?.()===0?[path.join(root,'scripts/provision-ubuntu.sh'),'--install']:['bash',path.join(root,'scripts/provision-ubuntu.sh'),'--install'],{stdio:'inherit',timeout:600000});
    }
  }
  engineResources(p,!!p.prepared);
  if(!p.prepared){await pinnedFiles(p);p.prepared=true;save(p);}else verifyFiles(p);
  console.log('Computer ready. No snapshot started. Next: node scripts/quickstart.mjs node --start');
}
async function node(options){
  const p=load();
  if(options.plan)return console.log(JSON.stringify({action:'node',directory:p.directory,backend:p.backend,changes:'None. --start begins or resumes the large download.'},null,2));
  if(!options.start)throw Error('Add --start to begin or resume the download.');
  if(!p.prepared)throw Error('Finish computer preparation first.');
  if(p.backend==='wsl')command(p,'systemctl',['start','docker']);
  verifyFiles(p);
  let c=ownContainer(p);
  hostResources(p.data,!!c);engineResources(p,!!c);
  if(c){if(resumeDecision(c,p)==='start')docker(p,['start',c.Id]);}
  else{
    try{await fetch('http://127.0.0.1:3381/v1/info',{signal:AbortSignal.timeout(1500)});throw Error('Another local node is already answering. Nothing started.');}catch(e){if(e.message.startsWith('Another local'))throw e;}
    docker(p,[...compose(p),'up','-d','--no-deps','snapchain'],{timeout:600000,stdio:'inherit'});
  }
  c=ownContainer(p);if(!c?.State?.Running)throw Error('Node exited. Check status; do not delete the data.');
  resumeDecision(c,p);keepWslAlive(p,c);
  console.log('Server running. Download → unpack → catch up. Next: node scripts/quickstart.mjs app');
}
function protectSecret(file){
  if(process.platform==='win32'){
    const who=`${process.env.USERDOMAIN}\\${process.env.USERNAME}`;
    exec('icacls.exe',[file,'/inheritance:r','/grant:r',who+':(F)','SYSTEM:(F)']);
  }else fs.chmodSync(file,0o600);
}
function account(options){
  const config=accountSettings({fid:options.fid,follow:options.follow,confirmed:options['confirm-test-account']===true});
  if(options.plan)return console.log(JSON.stringify({...config,changes:'No key created. Each public action still needs approval.'},null,2));
  const dir=path.join(runtime,'test-accounts',String(config.fid));fs.mkdirSync(dir,{recursive:true,mode:0o700});
  const file=path.join(dir,'app-signer.json');
  if(!fs.existsSync(file)){
    fs.writeFileSync(file,JSON.stringify({privateKey:randomBytes(32).toString('hex')}),{flag:'wx',mode:0o600});protectSecret(file);
  }
  fs.writeFileSync(path.join(runtime,'test-config.json'),JSON.stringify(config,null,2));
  console.log('Test account configured. The app key is local and has no account permission yet. Restart app, then review the wallet permission in your browser.');
}
function app(){
  const children=[];
  if(!fs.existsSync(path.join(root,'node_modules/viem'))){
    const cli=process.env.npm_execpath;
    if(cli)exec(process.execPath,[cli,'ci','--ignore-scripts','--no-fund'],{cwd:root,stdio:'inherit',timeout:600000});
    else exec(process.platform==='win32'?'cmd.exe':'npm',process.platform==='win32'?['/d','/s','/c','npm.cmd ci --ignore-scripts --no-fund']:['ci','--ignore-scripts','--no-fund'],{cwd:root,stdio:'inherit',timeout:600000});
  }
  for(const name of ['client-server.mjs',...(fs.existsSync(path.join(runtime,'test-config.json'))?['write-server.mjs']:[])]){
    const child=spawn(process.execPath,[path.join(root,'scripts',name)],{cwd:root,stdio:'inherit'});children.push(child);
    child.on('exit',code=>{if(code){console.error(name+' stopped. Check the message above.');process.exitCode=code;}});
  }
  console.log('Keep this terminal open. Reading: http://127.0.0.1:3422/ . Posting is optional; configure a test account first.');
  process.on('SIGINT',()=>children.forEach(c=>c.kill('SIGINT')));
}
try{
  if(Number(process.versions.node.split('.')[0])<24)throw Error('Node.js24 or newer is required.');
  const options=parseArguments(process.argv.slice(2));
  if(!['win32','linux'].includes(process.platform))throw Error('This test build supports Windows11 x64 and Ubuntu24.04 x64.');
  if(options.action==='computer')await computer(options);
  else if(options.action==='node')await node(options);
  else if(options.action==='account')account(options);
  else if(options.action==='app')app();
  else if(options.action==='wizard'){
    if(!options.data)throw Error('Choose a data folder with --data.');
    if(process.platform==='win32')windowsPlan(options.data);else makePlan(options.data);
    const {startWizard}=await import('./setup-wizard.mjs');
    startWizard({root,runtime,data:options.data});
  }
  else if(options.action==='status'){
    const p=load(),c=ownContainer(p);
    if(!c)console.log('No node has been created yet.');
    else{console.log(JSON.stringify({container:c.Name,running:c.State.Running,status:c.State.Status}));console.log(docker(p,['logs','--tail','8',c.Id]));}
  }else console.log('computer --data <folder> --plan | computer --data <folder> --install | node --start | app | status | account --fid <testFID> --follow <otherFID> --confirm-test-account');
}catch(error){console.error(error.message);process.exitCode=1;}
