import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import {randomBytes} from 'node:crypto';
import {spawn} from 'node:child_process';
import {readNodeStatus} from './node-status.mjs';
import {resourceCheck} from './quickstart-core.mjs';
import {wizardAllowed} from './wizard-controls.mjs';
export function startWizard({root,runtime,data}){
  const token=randomBytes(32).toString('hex');let busy=false,note='',logs='',app=null;
  function launch(args){return new Promise((resolve,reject)=>{
    const child=spawn(process.execPath,[path.join(root,'scripts/quickstart.mjs'),...args],{cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']});
    for(const stream of [child.stdout,child.stderr])stream.on('data',chunk=>{logs=(logs+String(chunk)).slice(-12000);});
    child.on('error',reject);child.on('exit',code=>code===0?resolve():reject(Error('Step stopped. Read the details below before retrying.')));
  });}
  async function state(){
    const node=await readNodeStatus();let disk=data;
    let appReady=false;
    if(node.api)try{const r=await fetch('http://127.0.0.1:3422/api/status',{signal:AbortSignal.timeout(3000)});appReady=r.ok&&!!(await r.json()).api;}catch{}
    while(!fs.existsSync(disk)&&path.dirname(disk)!==disk)disk=path.dirname(disk);
    let free=0;try{const s=fs.statfsSync(disk);free=s.bavail*s.bsize;}catch{}
    const resume=fs.existsSync(path.join(runtime,'quickstart-install.json'));
    const machine=resourceCheck({cpus:os.cpus().length,memory:os.totalmem(),free},resume);
    let details=logs;
    const liveLog=path.join(runtime,'quickstart-node.log');
    if(fs.existsSync(liveLog)){
      const file=fs.openSync(liveLog,'r');try{const size=fs.fstatSync(file).size,b=Buffer.alloc(Math.min(size,10000));fs.readSync(file,b,0,b.length,Math.max(0,size-b.length));details+='\n'+b.toString();}finally{fs.closeSync(file);}
    }
    return {busy,note,logs:details.slice(-18000),data,node,machine,appReady,resume,freeTB:(free/1e12).toFixed(2)};
  }
  const html=fs.readFileSync(path.join(root,'setup-wizard.html'),'utf8').replace('__TOKEN__',token);
  const server=http.createServer(async(req,res)=>{
    res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');
    if(req.headers.host!=='127.0.0.1:3424'){res.writeHead(403);res.end();return;}
    if(req.method==='GET'&&req.url==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html);return;}
    res.setHeader('Content-Type','application/json');
    try{
      if(req.method==='GET'&&req.url==='/state'){res.end(JSON.stringify(await state()));return;}
      if(req.method!=='POST'||!['/install','/open'].includes(req.url)){res.writeHead(404);res.end('{}');return;}
      let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>1024)throw Error('Request too large');}
      wizardAllowed(req.headers,token,JSON.parse(raw));if(busy)throw Error('A step is already running.');
      const current=await state();
      if(req.url==='/install'){
        if(current.node.api)throw Error('A local server already exists. Open the app instead; do not download another copy.');
        const resume=fs.existsSync(path.join(runtime,'quickstart-install.json'));
        if(!current.machine.ready&&!resume)throw Error('This computer does not meet the fresh-install requirements.');
        busy=true;logs='';note='Preparing the computer…';res.writeHead(202);res.end('{"ok":true}');
        launch(['computer','--data',data,'--install']).then(()=>{note='Starting or resuming the server…';return launch(['node','--start']);}).then(()=>{note='Server started. Downloading, unpacking and catching up take time.';}).catch(e=>{note=e.message;}).finally(()=>{busy=false;});return;
      }
      if(!current.node.api)throw Error('Wait until the server is answering before opening the app.');
      try{const r=await fetch('http://127.0.0.1:3422/api/status',{signal:AbortSignal.timeout(1500)});if(r.ok){res.end('{"ok":true}');return;}}catch{}
      if(app&&!app.killed)throw Error('The app is starting. Try its link shortly.');
      app=spawn(process.execPath,[path.join(root,'scripts/quickstart.mjs'),'app'],{cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']});
      for(const stream of [app.stdout,app.stderr])stream.on('data',chunk=>{logs=(logs+String(chunk)).slice(-12000);});
      app.on('exit',()=>{app=null;});app.on('error',e=>{note=e.message;app=null;});
      res.end('{"ok":true}');
    }catch(e){res.writeHead(400);res.end(JSON.stringify({error:e.message}));}
  });
  server.listen(3424,'127.0.0.1',()=>console.log('Setup: http://127.0.0.1:3424/ . Keep this terminal open. No installation starts until you approve it on that page.'));
}
