export async function waitForAuthorizationReady(read,{sleep=ms=>new Promise(r=>setTimeout(r,ms)),attempts=60}={}){
 for(let attempt=0;attempt<attempts;attempt++){
  const state=await read();
  if(state.ready)return state;
  if(attempt+1<attempts)await sleep(1000);
 }
 throw Error('Server not ready after waiting. No authorization submitted.');
}
