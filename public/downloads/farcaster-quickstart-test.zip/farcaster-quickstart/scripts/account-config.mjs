import fs from 'node:fs';
import path from 'node:path';
import {accountSettings} from './quickstart-core.mjs';
export function resolveAccount(config,legacyExists){
  if(config){const s=accountSettings({fid:config.fid,follow:config.followFid,confirmed:true});return {...s,relativeDir:`runtime/test-accounts/${s.fid}`,legacy:false};}
  if(legacyExists)return {fid:3356434,followFid:859428,relativeDir:'runtime/test-account',legacy:true};
  throw Error('Configure a separate test account first: quickstart account --fid <testFID> --follow <otherFID> --confirm-test-account');
}
export function readAccountConfig(root){
  const file=path.join(root,'runtime/test-config.json');
  return resolveAccount(fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):null,fs.existsSync(path.join(root,'runtime/test-account/actions.json')));
}
