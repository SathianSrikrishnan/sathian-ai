const nodes=['http://127.0.0.1:3381','https://snap.farcaster.xyz:3381','https://crackle.farcaster.xyz:3381'];
export async function verifyPostReadback({hash,fid,text},fetcher=fetch){
 if(!/^0x[0-9a-f]{40}$/i.test(hash)||!Number.isSafeInteger(fid)||fid<=0||fid===859428)throw Error('Invalid recorded test post');
 const results=await Promise.all(nodes.map(async(origin)=>{
  try{const r=await fetcher(`${origin}/v1/castById?fid=${fid}&hash=${hash}`,{signal:AbortSignal.timeout(8000)});if(!r.ok)throw Error();const m=await r.json();return {origin,verified:m.hash===hash&&m.data?.fid===fid&&m.data?.castAddBody?.text===text};}
  catch{return {origin,verified:false};}
 }));
 return {checkedAt:new Date().toISOString(),hash,localVerified:results[0].verified,networkVerified:results.slice(1).every(r=>r.verified),results};
}
