import http from 'node:http';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { fetchCasts } from './client-data.mjs';
import { readNodeStatus } from './node-status.mjs';
const html=fs.readFileSync(fileURLToPath(new URL('../client-simple.html',import.meta.url)));
const stateScript=fs.readFileSync(fileURLToPath(new URL('./client-state.mjs',import.meta.url)));
const server=http.createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');
  if(req.method!=='GET'){res.writeHead(405);res.end('Read-only local client');return;}
  const url=new URL(req.url,'http://127.0.0.1:3422');
  if(url.pathname==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html);return;}
  if(url.pathname==='/client-state.mjs'){res.setHeader('Content-Type','text/javascript; charset=utf-8');res.end(stateScript);return;}
  res.setHeader('Content-Type','application/json');
  if(url.pathname==='/api/casts'){
    try{const result=await fetchCasts(url.searchParams.get('fid'),fetch,{mode:url.searchParams.get('mode')||'all',app:url.searchParams.get('app')});res.writeHead(result.ok?200:503);res.end(JSON.stringify(result));}
    catch{res.writeHead(400);res.end(JSON.stringify({ok:false,message:'Use whole-number account and app numbers, and a valid filter.'}));}return;
  }
  if(url.pathname==='/api/status'){
    res.end(JSON.stringify(await readNodeStatus()));return;
  }
  res.writeHead(404);res.end('{}');
});
server.listen(3422,'127.0.0.1',()=>console.log('Local client: http://127.0.0.1:3422'));
