import path from 'node:path';
export const sourceRevision='fc87f2686472598143062a00e1c2b2633b2d87ab';
export const image='farcasterxyz/snapchain@sha256:15c19fb83091ecf86a9e7ec69d00aa70efd57fbf492e759fa368b954a803ee82';
export function makePlan(directory){
  if(typeof directory!=='string'||!path.posix.isAbsolute(directory)||directory.includes('\\')||directory.includes('\0'))throw Error('Choose an absolute Linux data directory.');
  directory=path.posix.resolve(directory);
  if(directory==='/'||directory==='/opt/farcaster-node'||directory.startsWith('/opt/farcaster-node/'))throw Error('Choose a new directory, separate from the existing node.');
  return {directory,project:'farcaster-quickstart',sourceRevision,image};
}
export function checkMachine(s){
  const [major,minor]=String(s.composeVersion??'').replace(/^v/,'').split('.').map(Number);
  const checks=[
    {name:'Linux x64',ok:s.platform==='linux'&&s.arch==='x64'},
    {name:'4 CPU cores available',ok:s.cpus>=4&&s.dockerCpus>=4},
    {name:'16 GB RAM available',ok:s.memory>=16e9&&s.dockerMemory>=16e9},
    {name:'2 TB free on selected disk',ok:s.free>=2e12},
    {name:'Docker running',ok:s.docker===true},
    {name:'Docker Compose 2.24 or newer',ok:major>2||(major===2&&minor>=24)}
  ];
  return {ready:checks.every(c=>c.ok),checks};
}
export function composeOverride(){return `services:
  snapchain:
    image: ${image}
    pull_policy: missing
    restart: "no"
    mem_limit: 16g
    cpus: 4
    environment:
      SNAPCHAIN_SNAPSHOT__SNAPSHOT_DOWNLOAD_DIR: .rocks.snapshot/work
    extra_hosts:
      - "statsd:127.0.0.1"
    ports: !override
      - "127.0.0.1:3381:3381/tcp"
      - "127.0.0.1:3383:3383/tcp"
`;}
