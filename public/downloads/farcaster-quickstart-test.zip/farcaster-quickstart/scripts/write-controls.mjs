export function checkConsent(body){if(body.approved!==true)throw Error('Explicit owner approval is required.');}
export function gates(s={}) {
  const shards=s.info?.shardInfos??[];
  const current=shards.length===3 && [0,1,2].every(id=>shards.some(v=>v.shardId===id&&Number.isFinite(v.blockDelay)&&v.blockDelay>=0&&v.blockDelay<10));
  const reasons=[];
  if(!current||s.currentSamples<2)reasons.push('The server is still catching up.');
  if(!/^0x[0-9a-f]{40}$/i.test(s.custody??''))reasons.push('The server has not verified the test account owner yet.');
  if(!(s.storage>0))reasons.push('The server has not verified the test account’s storage allowance yet.');
  return {ready:reasons.length===0,current,reasons};
}
export function checkRequest(headers,token) {
  if(headers.host!=='127.0.0.1:3423'||headers.origin!=='http://127.0.0.1:3423'||headers['x-test-token']!==token||headers['content-type']!=='application/json')throw Error('Request rejected');
}
