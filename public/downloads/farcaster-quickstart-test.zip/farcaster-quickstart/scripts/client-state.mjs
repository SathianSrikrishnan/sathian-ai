export function clientState(s) {
  if (s.engine?.running === false) return {canRead:false,title:'Server stopped',description:'The server is not running.',instruction:'Check it before resuming. Keep the existing data.'};
  if (s.api && s.engine?.running === true) return {canRead:true,title:'Ready to try reading posts',description:'Your server is answering.',instruction:'Press Read posts below.'};
  if (/unpack|unzip/i.test(s.phase ?? '')) return {canRead:false,title:'Opening the downloaded files',description:'The server is preparing its data.',instruction:'No clicks needed. Keep the computer awake and connected.'};
  return {canRead:false,title:'Preparing Farcaster data',description:'The server is not answering yet.',instruction:'No clicks needed. Keep the computer awake and connected.'};
}
