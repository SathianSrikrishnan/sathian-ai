import { decodeAbiParameters, parseAbiParameters } from 'viem';
const origin = 'http://127.0.0.1:3381';
function requestingApp(signer) {
  let fid=signer.requestFid;
  if (!fid) {
    const body=signer.onChainEvent?.signerEventBody;
    if (body?.metadataType !== 1 || typeof body.metadata !== 'string') return null;
    try {
      const bytes=body.metadata.startsWith('0x')?body.metadata:`0x${Buffer.from(body.metadata,'base64').toString('hex')}`;
      const [metadata]=decodeAbiParameters(parseAbiParameters('(uint256 requestFid, address requestSigner, bytes signature, uint256 deadline)'),bytes);
      fid=metadata.requestFid;
    } catch { return null; }
  }
  const n=Number(fid);
  return Number.isSafeInteger(n)&&n>0?n:null;
}
export function castPath(fid) {
  if (!/^[1-9]\d*$/.test(String(fid)) || !Number.isSafeInteger(Number(fid))) throw new Error('Enter a positive whole-number FID.');
  return `/v1/castsByFid?fid=${fid}&pageSize=20&reverse=true`;
}
export function summarizeCast(message) {
  return { fid: message.data?.fid, hash: message.hash,
    createdAt: new Date((1609459200 + message.data.timestamp) * 1000).toISOString(),
    text: message.data?.castAddBody?.text ?? '' };
}
export async function fetchCasts(fid, fetcher = fetch, options = {}) {
  const route = castPath(fid);
  const mode=options.mode || 'all';
  if (!['all','include','exclude'].includes(mode)) throw Error('Choose all, include or exclude.');
  if (mode !== 'all') castPath(options.app);
  try {
    const response = await fetcher(origin + route, { signal: AbortSignal.timeout(5000) });
    if (!response.ok) return { ok: false, reason: 'node_response', message: `Node returned HTTP ${response.status}. No feed loaded.` };
    const data = await response.json();
    if (!Array.isArray(data.messages)) return { ok: false, reason: 'invalid_response', message: 'Node response did not contain casts.' };
    if (mode === 'all') return { ok: true, source: origin, casts: data.messages.map(summarizeCast) };
    const registry=await fetcher(`${origin}/v1/signersByFid?fid=${fid}`,{signal:AbortSignal.timeout(5000)});
    if (!registry.ok) return {ok:false,reason:'origin_unavailable',message:'Cannot check which apps sent these posts. No filter was applied.'};
    const entries=await registry.json();
    if (!Array.isArray(entries.signers)||entries.nextPageToken) return {ok:false,reason:'origin_unavailable',message:'App list is incomplete. No filter was applied.'};
    const keys=new Map(entries.signers.map(s=>[s.key?.toLowerCase(),requestingApp(s)]));
    const posts=data.messages.map(m=>({...summarizeCast(m),appFid:keys.get(m.signer?.toLowerCase())??null}));
    return {ok:true,source:origin,window:20,unknownOrigins:posts.filter(p=>p.appFid===null).length,
      casts:posts.filter(p=>mode==='include'?p.appFid===Number(options.app):p.appFid!==Number(options.app))};
  } catch { return { ok: false, reason: 'node_unavailable', message: 'Your node is not serving casts yet. Check snapshot progress; no hosted feed was substituted.' }; }
}
