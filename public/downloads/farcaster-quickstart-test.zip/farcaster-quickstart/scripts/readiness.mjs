export function assess({ cpus, memoryBytes, freeDiskBytes, docker, dockerMemoryBytes, networkingVerified = false }) {
  const checks = [
    { name: 'Host logical processors', ok: cpus >= 4, detail: `${cpus} logical processors; physical-core count is recorded separately` },
    { name: 'Host memory', ok: memoryBytes >= 16e9, detail: `${(memoryBytes / 1e9).toFixed(1)} GB` },
    { name: 'Selected data disk free space', ok: freeDiskBytes >= 2e12, detail: `${(freeDiskBytes / 1e12).toFixed(2)} TB; performance not measured` },
    { name: 'Docker engine', ok: docker === true, detail: docker ? 'Responding' : 'Unavailable or timed out; not ready to start node' },
    { name: 'Docker memory allocation', ok: docker === true && dockerMemoryBytes >= 16e9, detail: docker ? `${(dockerMemoryBytes / 1e9).toFixed(1)} GB` : 'Unknown until engine responds' },
    { name: 'Network reachability', ok: networkingVerified, detail: networkingVerified ? 'Verified separately' : 'Not verified; no router/firewall changes made' }
  ];
  return { ready: checks.every(check => check.ok), checks };
}
