import {parseNodeInfo} from './node-info.mjs';
export async function readNodeStatus(fetcher=fetch){
  const checkedAt=new Date().toISOString();
  try{
    const response=await fetcher('http://127.0.0.1:3381/v1/info',{signal:AbortSignal.timeout(4000)});
    if(!response.ok)throw Error();
    const api=parseNodeInfo(await response.text());
    if(typeof api.version!=='string'||!Array.isArray(api.shardInfos))throw Error('Not a Farcaster node response');
    const current=[0,1,2].every(id=>api.shardInfos?.some(s=>s.shardId===id&&Number.isFinite(s.blockDelay)&&s.blockDelay>=0&&s.blockDelay<10));
    return {checkedAt,api,engine:{running:true},phase:current?'Current':'Catching up',current};
  }catch{return {checkedAt,api:null,phase:'Downloading or preparing data',current:false};}
}
