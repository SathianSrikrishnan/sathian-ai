export function parseNodeInfo(raw){
 // Preserve unsigned 64-bit delay before JSON Number rounding. Snapchain's
 // block shard uses unsigned subtraction; data shards use saturating_sub.
 const info=JSON.parse(raw.replace(/("blockDelay"\s*:\s*)(\d+)/g,'$1"$2"'));
 for(const shard of info.shardInfos??[]){
  const delay=BigInt(shard.blockDelay),ahead=(1n<<64n)-delay;
  if(shard.shardId===0&&ahead>=1n&&ahead<=3n){shard.rawBlockDelay=String(delay);shard.clockAheadSeconds=Number(ahead);shard.blockDelay=0;}
  else shard.blockDelay=Number(delay);
 }
 return info;
}
