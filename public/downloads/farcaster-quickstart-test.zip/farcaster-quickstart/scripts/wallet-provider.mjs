export function selectMetaMask(announced,legacy){
 const known=announced.find(p=>p.info?.rdns==='io.metamask'&&p.provider?.request);
 if(known)return known.provider;
 const candidates=legacy?.providers??[legacy];
 const match=candidates.find(p=>p?.isMetaMask&&!p.isPhantom&&!p.isRabby&&p.request);
 if(!match)throw Error('MetaMask was not detected. Open MetaMask and unlock it, then reload this page. No other wallet will be used.');
 return match;
}
export async function prepareMetaMask(provider){
 if(await provider.request({method:'eth_chainId'})!=='0x1'){
  await provider.request({method:'wallet_switchEthereumChain',params:[{chainId:'0x1'}]});
 }
 if(await provider.request({method:'eth_chainId'})!=='0x1')throw Error('MetaMask is not on Ethereum Mainnet. No permission signatures requested.');
}
export function walletTypedData(typed){
 const fields=[['name','string'],['version','string'],['chainId','uint256'],['verifyingContract','address'],['salt','bytes32']];
 const EIP712Domain=fields.filter(([name])=>typed.domain[name]!==undefined).map(([name,type])=>({name,type}));
 return {...typed,types:{...typed.types,EIP712Domain}};
}
