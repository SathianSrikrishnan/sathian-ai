// Offline builders only. No network submission or custody-key file access.
import { sdk as h } from './farcaster-sdk.mjs';
import {verifyTypedData} from 'viem';
export const TEST_TEXT='Testing my own Farcaster client: this post was sent through my local node. This is a development account.';
const targetHash='0x8f5c04d697cc11d687a7df2ccd300605be5ff475';
const bytes=hex=>Uint8Array.from(Buffer.from(hex.slice(2),'hex'));
function source(fid) {
  if(!Number.isSafeInteger(fid)||fid<=0||fid===859428)throw Error('Use a separate test account FID.');
  return {fid,network:h.FarcasterNetwork.MAINNET};
}
function unwrap(result){if(result.isErr())throw Error(result.error.message);return result.value;}
function nextNonce(n){if(!Number.isSafeInteger(n)||n<0||n>=Number.MAX_SAFE_INTEGER)throw Error('Invalid nonce');return n+1;}
export async function buildAction(action,{fid,signer,castHash,followFid=859428,likeFid=859428,likeHash=targetHash}) {
  const options=source(fid);
  if(!Number.isSafeInteger(followFid)||followFid<=0||!Number.isSafeInteger(likeFid)||likeFid<=0)throw Error('Invalid test target account');
  switch(action){
    case 'post':return unwrap(await h.makeCastAdd({text:TEST_TEXT,embeds:[],embedsDeprecated:[],mentions:[],mentionsPositions:[],type:h.CastType.CAST},options,signer));
    case 'follow':case 'unfollow':return unwrap(await h[action==='follow'?'makeLinkAdd':'makeLinkRemove']({type:'follow',targetFid:followFid},options,signer));
    case 'like':case 'unlike':
      if(!/^0x[0-9a-f]{40}$/i.test(likeHash??''))throw Error('Publish the test post before liking it.');
      return unwrap(await h[action==='like'?'makeReactionAdd':'makeReactionRemove']({type:h.ReactionType.LIKE,targetCastId:{fid:likeFid,hash:bytes(likeHash)}},options,signer));
    case 'remove-post':
      if(!/^0x[0-9a-f]{40}$/i.test(castHash??''))throw Error('Provide the recorded test post hash.');
      return unwrap(await h.makeCastRemove({targetHash:bytes(castHash)},options,signer));
    default:throw Error('Unsupported test action');
  }
}
export async function buildAuthorization({fid,signer,custody,currentUserNonce}) {
  const options=source(fid),key=unwrap(await signer.getSignerKey());
  const body=unwrap(await h.makeKeyAddBody({fid:BigInt(fid),requestFid:BigInt(fid),key,scopes:[1,2,3,4,5,6],ttl:86400,nonce:nextNonce(currentUserNonce),deadline:unwrap(h.getFarcasterTime())+600},custody));
  return unwrap(await h.makeKeyAdd(body,options,signer));
}
export async function buildRevocation({fid,signer,requesterNonce}) {
  const options=source(fid),key=unwrap(await signer.getSignerKey());
  const body=unwrap(h.makeKeyRemoveBodySelfRevoke({key,nonce:nextNonce(requesterNonce),deadline:unwrap(h.getFarcasterTime())+600}));
  return unwrap(await h.makeKeyRemove(body,options,signer));
}
export async function buildSignedAuthorization({fid,signer,custody,request,authorization,requestSignature,authorizationSignature}) {
  const options=source(fid),key=unwrap(await signer.getSignerKey()),hex='0x'+Buffer.from(key).toString('hex'),m=authorization.message;
  if(String(m.fid)!==String(fid)||String(request.message.requestFid)!==String(fid)||m.key!==hex||request.message.key!==hex||m.ttl!==86400||m.keyType!==1||JSON.stringify(m.scopes)!=='[1,2,3,4,5,6]'||String(m.deadline)!==String(request.message.deadline))throw Error('Unexpected permission request');
  for(const [typed,signature]of [[request,requestSignature],[authorization,authorizationSignature]])if(!await verifyTypedData({...typed,address:custody,signature}))throw Error('Wrong authorization signature');
  const metadata=unwrap(h.encodeGaslessSignedKeyRequestMetadata({requestFid:BigInt(fid),requestSigner:custody,signature:bytes(requestSignature),deadline:BigInt(m.deadline)}));
  const body=h.KeyAddBody.create({key,keyType:1,scopes:m.scopes,ttl:86400,nonce:m.nonce,deadline:Number(m.deadline),custodySignature:bytes(authorizationSignature),metadata,metadataType:h.METADATA_TYPE_SIGNED_KEY_REQUEST});
  return unwrap(await h.makeKeyAdd(body,options,signer));
}

