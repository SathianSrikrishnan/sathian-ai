import http from 'node:http';
import fs from 'node:fs';
import {randomBytes} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {sdk as h} from './farcaster-sdk.mjs';
import {buildAction,buildRevocation,buildSignedAuthorization,TEST_TEXT} from './signing.mjs';
import {gates,checkRequest,checkConsent} from './write-controls.mjs';
import {readAccountConfig} from './account-config.mjs';
import {waitForAuthorizationReady} from './authorization-readiness.mjs';
import {verifyPostReadback} from './post-proof.mjs';
import {parseNodeInfo} from './node-info.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const account=readAccountConfig(root),FID=account.fid,accountDir=root+account.relativeDir+'/';
const secret=JSON.parse(fs.readFileSync(accountDir+'app-signer.json','utf8'));
const signer=new h.NobleEd25519Signer(Buffer.from(secret.privateKey,'hex'));
const key=(await signer.getSignerKey())._unsafeUnwrap();
const publicKey='0x'+Buffer.from(key).toString('hex');
const token=randomBytes(32).toString('hex');
const rpc=h.getInsecureHubRpcClient('127.0.0.1:3383');
let samples=0,lastSampleAt=0,busy=false,pending=null,revoked=false;
const receipts=fs.existsSync(accountDir+'actions.json')?JSON.parse(fs.readFileSync(accountDir+'actions.json','utf8')):[];
revoked=receipts.some(r=>r.action==='revoke');
function save(){fs.writeFileSync(accountDir+'actions.json',JSON.stringify(receipts,null,2),{mode:0o600});}
const ok=result=>{if(result.isErr())throw Error(result.error.message);return result.value;};
async function read(route){const r=await fetch('http://127.0.0.1:3381/v1/'+route,{signal:AbortSignal.timeout(8000)});if(!r.ok)throw Error('Local node cannot verify account yet');return route==='info'?parseNodeInfo(await r.text()):r.json();}
async function state(){
  const [info,storage,signerResult,events]=await Promise.all([read('info'),read('storageLimitsByFid?fid='+FID),rpc.getSignersByFid({fid:FID,requesterFids:[FID]},{deadline:Date.now()+8000}),rpc.getOnChainEvents({fid:FID,eventType:3},{deadline:Date.now()+8000})]);
  const signers=ok(signerResult);
  const registrations=ok(events).events.filter(e=>e.idRegisterEventBody?.to?.length===20).sort((a,b)=>a.blockNumber-b.blockNumber||a.logIndex-b.logIndex);
  const owner=registrations.at(-1)?.idRegisterEventBody?.to;
  const custody=owner?'0x'+Buffer.from(owner).toString('hex'):null;
  const base={info,custody,storage:storage.units,currentSamples:samples};
  if(Date.now()-lastSampleAt>10000){samples=gates(base).current?samples+1:0;lastSampleAt=Date.now();}
  const registered=(signers.signers??[]).some(s=>'0x'+Buffer.from(s.key??[]).toString('hex')===publicKey);
  return {...base,currentSamples:samples,...gates({...base,currentSamples:samples}),signers,registered,revoked,receipts,publicKey,fid:FID,text:TEST_TEXT};
}
function typedRequests(s){
  const deadline=ok(h.getFarcasterTime())+600;
  const request={...h.GASLESS_SIGNED_KEY_REQUEST_EIP_712_TYPES,primaryType:'SignedKeyRequest',message:{requestFid:String(FID),key:publicKey,deadline:String(deadline)}};
  const authorization={...h.GASLESS_KEY_ADD_EIP_712_TYPES,primaryType:'KeyAdd',message:{fid:String(FID),key:publicKey,keyType:1,scopes:[1,2,3,4,5,6],ttl:86400,nonce:s.signers.currentUserNonce+1,deadline:String(deadline)}};
  pending={request,authorization,custody:s.custody,expiresAt:Date.now()+9*60000};
  return {request,authorization,custody:s.custody};
}
async function submit(message,action){
  const valid=await h.validations.validateMessage(message);ok(valid);
  if(receipts.some(r=>r.action===action))throw Error('This action was already attempted. Inspect its receipt before retrying.');
  const receipt={action,hash:'0x'+Buffer.from(message.hash).toString('hex'),at:new Date().toISOString(),status:'attempt recorded; result pending'};
  receipts.push(receipt);save();
  try{
    const r=await fetch('http://127.0.0.1:3381/v1/submitMessage',{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:h.Message.encode(message).finish(),signal:AbortSignal.timeout(12000)});
    if(!r.ok)throw Error('Node returned HTTP '+r.status);
    receipt.status='submitted; acceptance/readback still required';save();return receipt;
  }catch{receipt.status='submission not confirmed; manual readback required before any retry';save();throw Error(receipt.status);}
}
async function mutate(route,body){
  checkConsent(body);
  let s=await state();
  if(route==='/request'){
    if(!s.ready||s.registered||revoked||receipts.some(r=>r.action==='authorize'))throw Error(s.reasons.join(' ')||'Authorization already attempted or signer revoked; inspect receipts.');
    if(String(body.address).toLowerCase()!==s.custody.toLowerCase())throw Error('This wallet does not own the configured test account. Switch wallets; do not use the main account.');
    return typedRequests(s);
  }
  if(route==='/authorize'){
    const p=pending;
    if(!s.ready)s=await waitForAuthorizationReady(state);
    if(!s.ready||!p||Date.now()>p.expiresAt||s.custody!==p.custody||s.signers.currentUserNonce+1!==p.authorization.message.nonce)throw Error('Authorization expired or account state changed.');
    const msg=await buildSignedAuthorization({fid:FID,signer,...p,requestSignature:body.requestSignature,authorizationSignature:body.authorizationSignature});
    pending=null;
    return submit(msg,'authorize');
  }
  if(route==='/action'){
    const action=body.action;
    if(!['post','follow','like','unfollow','unlike','remove-post','revoke'].includes(action))throw Error('Unsupported action');
    if(!s.ready||!s.registered||revoked||receipts.some(r=>r.action==='revoke'))throw Error('Wait for a current server and confirmed app authorization, or inspect the revocation receipt.');
    if(receipts.some(r=>r.action===action))throw Error('Already submitted. Inspect the receipt before any retry.');
    if(action==='revoke'){
      const n=s.signers.requesterFidNonces?.[String(FID)];
      if(n===undefined)throw Error('Cannot verify revocation nonce. No request sent.');
      const result=await submit(await buildRevocation({fid:FID,signer,requesterNonce:n}),'revoke');revoked=true;return result;
    }
    const undo={'unfollow':'follow','unlike':'like','remove-post':'post'}[action];
    if(undo&&!receipts.some(r=>r.action===undo&&r.status.startsWith('submitted;')))throw Error('No confirmed submission for the matching test action. Inspect its receipt.');
    const castHash=receipts.find(r=>r.action==='post')?.hash;
    return submit(await buildAction(action,{fid:FID,signer,castHash,followFid:account.followFid,...(account.legacy?{}:{likeFid:FID,likeHash:castHash??''})}),action);
  }
  throw Error('Unknown operation');
}
const html=fs.readFileSync(root+'test-account.html','utf8').replaceAll('__FID__',String(FID)).replaceAll('__FOLLOW_FID__',String(account.followFid)).replaceAll('__LIKE_LABEL__',account.legacy?'the previously approved recruitment post':'the test post you publish below').replace('__TOKEN__',token).replace('__WALLET_HELPERS__',fs.readFileSync(root+'scripts/wallet-provider.mjs','utf8').replaceAll('export ',''));
http.createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');
  if(req.headers.host!=='127.0.0.1:3423'){res.writeHead(403);res.end();return;}
  if(req.method==='GET'&&req.url==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html);return;}
  res.setHeader('Content-Type','application/json');
  try{
    if(req.method==='GET'&&req.url==='/post-proof'){
      const receipt=receipts.find(r=>r.action==='post');
      if(!receipt)throw Error('No test post has been submitted.');
      const proof=await verifyPostReadback({hash:receipt.hash,fid:FID,text:TEST_TEXT});
      fs.writeFileSync(accountDir+'independent-post-proof.json',JSON.stringify(proof,null,2),{mode:0o600});
      res.end(JSON.stringify(proof));return;
    }
    if(req.method==='GET'&&req.url==='/state'){const s=await state();res.end(JSON.stringify(s));return;}
    if(req.method!=='POST'){res.writeHead(404);res.end('{}');return;}
    checkRequest(req.headers,token);if(busy)throw Error('A request is already being processed.');
    busy=true;try{let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>12000)throw Error('Request too large');}res.end(JSON.stringify(await mutate(req.url,JSON.parse(raw))));}finally{busy=false;}
  }catch(error){res.writeHead(400);res.end(JSON.stringify({error:error.message}));}
}).listen(3423,'127.0.0.1',()=>console.log('Local test-account controls: http://127.0.0.1:3423'));
