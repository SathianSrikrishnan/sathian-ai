export function parseProgress(log, now = Date.now()) {
  const matches = [...log.matchAll(/([^\n]*?)Completed download[^\n]*Progress: (\d+)\/(\d+) chunks[^\n]*/g)];
  const last = matches.at(-1);
  const line = log.trim().split(/\r?\n/).at(-1) ?? '';
  const timestamp = line.match(/\d{4}-\d\d-\d\dT[\d:.]+Z/)?.[0];
  const lastProgressAt = last?.[0].match(/\d{4}-\d\d-\d\dT[\d:.]+Z/)?.[0];
  const completed = last ? Number(last[2]) : 0;
  const total = last ? Number(last[3]) : 0;
  const extraction = /extract|unpack|decompress|unzipping/i.test(line);
  const stale = lastProgressAt ? now - Date.parse(lastProgressAt) > 15 * 60e3 : false;
  return {
    completed, total, percent: total ? completed / total * 100 : 0,
    eta: last?.[0].match(/ETA: ([^)]+)/)?.[1] ?? null,
    lastProgressAt: lastProgressAt ?? null, lastLogAt: timestamp ?? null,
    phase: extraction ? 'Unpacking snapshot' : total && completed < total ? 'Downloading snapshot' : 'Initializing node',
    stalled: stale && !extraction && completed < total,
    latestLine: line.replace(/\u001b\[[0-9;]*m/g, '')
  };
}
