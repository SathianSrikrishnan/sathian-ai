export function wizardAllowed(headers,token,body){
  if(headers.host!=='127.0.0.1:3424'||headers.origin!=='http://127.0.0.1:3424'||headers['x-setup-token']!==token||headers['content-type']!=='application/json'||body.approved!==true)throw Error('Setup request rejected. Use the local page and confirm the action.');
}
