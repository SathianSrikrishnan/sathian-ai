import {createInterface} from 'node:readline/promises';
import {stdin,stdout} from 'node:process';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
if(Number(process.versions.node.split('.')[0])<24){console.error('Install Node.js24 or newer from nodejs.org, then try again.');process.exitCode=1;}
else{
  const prompt=createInterface({input:stdin,output:stdout});
  const data=(await prompt.question(process.platform==='win32'?'New data folder (for example D:\\FarcasterNode): ':'New data folder (for example /mnt/data/farcaster): ')).trim();prompt.close();
  const root=fileURLToPath(new URL('../',import.meta.url));
  const child=spawn(process.execPath,[path.join(root,'scripts/quickstart.mjs'),...(process.platform==='win32'?['wizard']:['computer']),'--data',data,...(process.platform==='win32'?[]:['--install'])],{stdio:'inherit',cwd:root});
  child.on('error',e=>{console.error(e.message);process.exitCode=1;});child.on('exit',code=>process.exitCode=code??1);
}
