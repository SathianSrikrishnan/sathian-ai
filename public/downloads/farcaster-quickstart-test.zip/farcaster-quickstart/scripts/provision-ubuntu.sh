#!/usr/bin/env bash
# Official Docker packages. Explicitly invoked only by the approved computer step.
set -euo pipefail
[[ "${1:-}" == --install ]] || { echo 'Review the plan, then add --install.' >&2; exit 1; }
[[ $(id -u) == 0 ]] || { echo 'Run the computer step with sudo.' >&2; exit 1; }
[[ -z "${WSL_DISTRO_NAME:-}" || "$WSL_DISTRO_NAME" == FarcasterQuickstart ]] || { echo 'Only the dedicated FarcasterQuickstart distro may be changed.' >&2; exit 1; }
source /etc/os-release
[[ "$ID" == ubuntu && "$VERSION_ID" == 24.04 && $(uname -m) == x86_64 ]] || { echo 'Ubuntu24.04 x64 is required.' >&2; exit 1; }
if ! command -v docker >/dev/null; then
  for package in docker.io podman-docker containerd runc; do
    if dpkg-query -W -f='${Status}' "$package" 2>/dev/null | grep -q 'install ok installed'; then
      echo "Existing $package needs manual review. Nothing removed." >&2; exit 1
    fi
  done
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y ca-certificates curl
  install -m0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/farcaster-docker.asc
  chmod a+r /etc/apt/keyrings/farcaster-docker.asc
  cat > /etc/apt/sources.list.d/farcaster-docker.sources <<'EOF'
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: noble
Components: stable
Architectures: amd64
Signed-By: /etc/apt/keyrings/farcaster-docker.asc
EOF
  apt-get update
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi
systemctl start docker
docker info --format '{{json .}}'
