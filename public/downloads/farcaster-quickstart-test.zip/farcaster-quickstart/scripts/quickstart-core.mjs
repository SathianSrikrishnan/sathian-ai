import path from 'node:path';
export function decodeOutput(value){
  if(value===null||value===undefined)return '';
  const text=Buffer.isBuffer(value)?value.toString((value[0]===255&&value[1]===254)||value[1]===0?'utf16le':'utf8'):String(value);
  return text.replace(/^\ufeff/,'').trim();
}
export function parseArguments(args){
  const out={action:args[0]??'help'};
  for(let n=1;n<args.length;n++){
    const name=args[n].replace(/^--/,'');
    if(['plan','install','start','confirm-test-account'].includes(name))out[name]=true;
    else if(['data','fid','follow'].includes(name)&&args[n+1]&&!args[n+1].startsWith('--'))out[name]=args[++n];
    else throw Error('Unknown or incomplete option: '+args[n]);
  }return out;
}
export function windowsPlan(value){
  if(typeof value!=='string'||!/^[A-Za-z]:[\\/][^\\/]/.test(value)||value.includes('\0'))throw Error('Choose a folder on a local drive, for example D:\\FarcasterQuickstart.');
  const data=path.win32.resolve(value),protectedPath='d:\\farcasterruntime';
  if(data.toLowerCase()===protectedPath||data.toLowerCase().startsWith(protectedPath+'\\'))throw Error('The existing FarcasterLab disk is protected. Choose a separate folder.');
  const distro='FarcasterQuickstart';
  return {backend:'wsl',data,distro,directory:'/opt/farcaster-quickstart',project:'farcaster-quickstart',installArgs:['--install','Ubuntu-24.04','--name',distro,'--location',data,'--vhd-size','3TB','--no-launch','--web-download']};
}
export function resourceCheck(s,resume=false){
  const checks=[{name:'4 CPU cores',ok:s.cpus>=4},{name:'16 GB RAM',ok:s.memory>=16e9},{name:resume?'100 GB remaining headroom':'2 TB free on selected disk',ok:s.free>=(resume?100e9:2e12)}];
  return {ready:checks.every(c=>c.ok),checks};
}
export function resumeDecision(container,plan){
  const labels=container.Config?.Labels??{};
  if(labels['com.docker.compose.project']!==plan.project||labels['com.docker.compose.project.working_dir']!==plan.directory||container.Config.Image!==plan.image)throw Error('This container does not match this installation. No changes made.');
  return container.State?.Running?'running':'start';
}
export function accountSettings({fid,follow,confirmed}){
  const f=Number(fid),t=Number(follow);
  if(!confirmed||!/^\d+$/.test(String(fid))||!/^\d+$/.test(String(follow))||!Number.isSafeInteger(f)||!Number.isSafeInteger(t)||f<=0||t<=0||f===859428||f===t)throw Error('Confirm a separate test account and a different account to follow.');
  return {fid:f,followFid:t};
}
