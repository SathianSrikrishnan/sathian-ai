// Core 0.20 bundles eager test factories using Faker 7 names. Keep the patched
// Faker 10 runtime and adapt only those obsolete factory APIs before SDK load.
import { faker } from '@faker-js/faker';
faker.datatype.number = options => faker.number.int(options);
faker.datatype.datetime = ({min,max}) => faker.date.between({from:min,to:max});
faker.random = {alphaNumeric: length => faker.string.alphanumeric(length)};
const between = faker.date.between.bind(faker.date);
faker.date.between = (first,second) => between(second === undefined ? first : {from:first,to:second});
export const sdk = await import('@farcaster/hub-nodejs');
