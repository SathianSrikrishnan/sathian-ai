import test from 'node:test';
import assert from 'node:assert/strict';
import {windowsPlan,resourceCheck,resumeDecision,accountSettings,parseArguments,decodeOutput} from '../scripts/quickstart-core.mjs';
test('Windows setup uses only a named new folder and dedicated distro',()=>{
  for(const value of ['D:\\','relative','D:\\FarcasterRuntime','D:\\FarcasterRuntime\\other','\\\\server\\share\\node'])assert.throws(()=>windowsPlan(value));
  const p=windowsPlan('E:\\My Farcaster');assert.equal(p.distro,'FarcasterQuickstart');assert.equal(p.data,'E:\\My Farcaster');
  assert.ok(p.installArgs.includes('--location'));assert.ok(p.installArgs.includes('3TB'));assert.ok(!p.installArgs.includes('FarcasterLab'));
});
test('resume needs spare room but does not demand a second 2TB allocation',()=>{
  const s={cpus:8,memory:32e9,free:1.9e12};
  assert.equal(resourceCheck(s,false).ready,false);assert.equal(resourceCheck(s,true).ready,true);
  assert.equal(resourceCheck({...s,free:50e9},true).ready,false);
});
test('only matching owned containers may resume; running one stays untouched',()=>{
  const plan={project:'farcaster-quickstart',directory:'/opt/farcaster-quickstart',image:'pinned'};
  const container={Config:{Image:'pinned',Labels:{'com.docker.compose.project':plan.project,'com.docker.compose.project.working_dir':plan.directory}},State:{Running:true}};
  assert.equal(resumeDecision(container,plan),'running');
  assert.equal(resumeDecision({...container,State:{Running:false}},plan),'start');
  assert.throws(()=>resumeDecision({...container,Config:{...container.Config,Image:'other'}},plan));
});
test('new account configuration is explicit, separate and never asks for custody secrets',()=>{
  for(const values of [{fid:859428,follow:123,confirmed:true},{fid:123,follow:123,confirmed:true},{fid:123,follow:456},{fid:'1&bad',follow:456,confirmed:true}])assert.throws(()=>accountSettings(values));
  assert.deepEqual(accountSettings({fid:'123',follow:'456',confirmed:true}),{fid:123,followFid:456});
});
test('argument parser rejects unknown flags instead of silently starting',()=>{
  assert.throws(()=>parseArguments(['computer','--oops']));
  assert.deepEqual(parseArguments(['computer','--data','E:\\Node','--plan']),{action:'computer',data:'E:\\Node',plan:true});
});
test('WSL UTF16 output and Linux UTF8 output preserve distro names and JSON',()=>{
  assert.equal(decodeOutput(Buffer.from('\ufeffFarcasterQuickstart\r\n','utf16le')),'FarcasterQuickstart');
  assert.equal(decodeOutput(Buffer.from('{"NCPU":4}\n')),'{"NCPU":4}');
});
