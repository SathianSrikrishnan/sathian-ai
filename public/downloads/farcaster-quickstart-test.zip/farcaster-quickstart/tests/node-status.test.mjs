import test from 'node:test';
import assert from 'node:assert/strict';
import {readNodeStatus} from '../scripts/node-status.mjs';
test('ready, catch-up and unreachable states come from the node itself, not a machine-specific tracker',async()=>{
  const fetcher=seconds=>async()=>({ok:true,text:async()=>JSON.stringify({version:'0.14.3',shardInfos:[0,1,2].map(shardId=>({shardId,blockDelay:seconds,maxHeight:123}))})});
  assert.equal((await readNodeStatus(fetcher(1))).phase,'Current');
  assert.equal((await readNodeStatus(fetcher(30))).phase,'Catching up');
  assert.equal((await readNodeStatus(async()=>{throw Error();})).api,null);
});
test('an unrelated JSON response cannot be labelled a working Farcaster server',async()=>{
  const s=await readNodeStatus(async()=>({ok:true,text:async()=>'{}'}));assert.equal(s.api,null);
});
