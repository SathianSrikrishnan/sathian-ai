import test from 'node:test';
import assert from 'node:assert/strict';
import { castPath, fetchCasts, summarizeCast } from '../scripts/client-data.mjs';
test('FID query cannot select arbitrary host or unbounded page size',()=>{
  assert.equal(castPath('185'),'/v1/castsByFid?fid=185&pageSize=20&reverse=true');
  for(const bad of ['0','-1','1e5','185&url=http://evil','https://evil','9007199254740993']) assert.throws(()=>castPath(bad));
});
test('node failure stays unavailable instead of inventing an empty successful feed',async()=>{
  const result=await fetchCasts('185',async()=>{throw new Error('ECONNREFUSED');});
  assert.equal(result.ok,false);assert.equal(result.reason,'node_unavailable');
});
test('real node message uses Farcaster epoch and preserves untrusted text as text',()=>{
  const result=summarizeCast({hash:'0xabc',data:{fid:185,timestamp:1,castAddBody:{text:'<img onerror=evil()>'}}});
  assert.equal(result.createdAt,'2021-01-01T00:00:01.000Z');assert.equal(result.text,'<img onerror=evil()>');
});
test('successful node response uses fixed local source and exposes returned casts',async()=>{
  let requested;
  const result=await fetchCasts('37',async url=>{requested=url;return {ok:true,json:async()=>({messages:[{hash:'0xabc',data:{fid:37,timestamp:1,castAddBody:{text:'actual response'}}}]})};});
  assert.equal(requested,'http://127.0.0.1:3381/v1/castsByFid?fid=37&pageSize=20&reverse=true');
  assert.equal(result.ok,true);assert.equal(result.casts[0].text,'actual response');
});
