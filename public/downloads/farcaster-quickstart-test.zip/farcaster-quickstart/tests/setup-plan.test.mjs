import test from 'node:test';
import assert from 'node:assert/strict';
import {makePlan,checkMachine,composeOverride} from '../scripts/setup-plan.mjs';
test('fresh data directory must be explicit, absolute and separate from existing lab',()=>{
  for(const path of ['','relative','/','/opt/farcaster-node','/opt/farcaster-node/child']) assert.throws(()=>makePlan(path));
  const plan=makePlan('/data/my-node');
  assert.equal(plan.project,'farcaster-quickstart');
  assert.equal(plan.directory,'/data/my-node');
  assert.ok(plan.sourceRevision.match(/^[a-f0-9]{40}$/));
  assert.ok(plan.image.includes('@sha256:'));
});
test('fail clearly for insufficient disk, memory, CPU, missing engine or unsupported system',()=>{
  const good={platform:'linux',arch:'x64',cpus:4,memory:20e9,free:2.5e12,dockerMemory:18e9,dockerCpus:4,composeVersion:'2.24.4',docker:true};
  assert.equal(checkMachine(good).ready,true);
  for(const change of [{platform:'win32'},{arch:'arm64'},{cpus:2},{memory:8e9},{free:1.9e12},{dockerMemory:8e9},{dockerCpus:2},{composeVersion:'2.20.0'},{docker:false}]) assert.equal(checkMachine({...good,...change}).ready,false);
});
test('compose override pins image, keeps API private and snapshot cleanup below mounted root',()=>{
  const text=composeOverride();
  assert.match(text,/sha256:/);assert.match(text,/127\.0\.0\.1:3381:3381/);
  assert.match(text,/\.rocks\.snapshot\/work/);assert.doesNotMatch(text,/3382:3382/);
});
