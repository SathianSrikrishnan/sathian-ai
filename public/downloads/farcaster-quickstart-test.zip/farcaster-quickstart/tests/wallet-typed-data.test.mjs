import test from 'node:test';
import assert from 'node:assert/strict';
import {randomBytes} from 'node:crypto';
import {signTypedData,SignTypedDataVersion} from '@metamask/eth-sig-util';
import {privateKeyToAccount} from 'viem/accounts';
import {verifyTypedData} from 'viem';
import {sdk} from '../scripts/farcaster-sdk.mjs';
import {walletTypedData} from '../scripts/wallet-provider.mjs';
test('MetaMask V4 signatures of JSON payload match SDK domain for both permissions',async()=>{
 const privateKey=randomBytes(32),account=privateKeyToAccount('0x'+privateKey.toString('hex'));
 for(const [base,primaryType,message] of [
  [sdk.GASLESS_SIGNED_KEY_REQUEST_EIP_712_TYPES,'SignedKeyRequest',{requestFid:'3356434',key:'0x'+'11'.repeat(32),deadline:'190000000'}],
  [sdk.GASLESS_KEY_ADD_EIP_712_TYPES,'KeyAdd',{fid:'3356434',key:'0x'+'11'.repeat(32),keyType:1,scopes:[1,2,3,4,5,6],ttl:86400,nonce:1,deadline:'190000000'}]
 ]){
  const typed={...base,primaryType,message};
  const broken=signTypedData({privateKey,data:JSON.parse(JSON.stringify(typed)),version:SignTypedDataVersion.V4});
  assert.equal(await verifyTypedData({...typed,address:account.address,signature:broken}),false);
  const wire=JSON.parse(JSON.stringify(walletTypedData(typed)));
  const signature=signTypedData({privateKey,data:wire,version:SignTypedDataVersion.V4});
  assert.equal(await verifyTypedData({...typed,address:account.address,signature}),true,primaryType);
 }
});
