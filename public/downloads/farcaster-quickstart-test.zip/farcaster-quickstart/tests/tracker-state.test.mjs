import test from 'node:test';
import assert from 'node:assert/strict';
import { parseProgress } from '../scripts/tracker-state.mjs';
const log='2026-10-21T10:00:00Z INFO Completed download of chunk (10 bytes). Progress: 108/5694 chunks (1%) (ETA: 5h23m)';
test('percentage uses actual chunk count rather than truncated log percentage',()=>{
  const s=parseProgress(log,Date.parse('2026-10-21T10:01:00Z'));
  assert.ok(s.percent>1.8 && s.percent<2);assert.equal(s.stalled,false);assert.equal(s.eta,'5h23m');
});
test('stale downloading warns but quiet extraction is not automatically stalled',()=>{
  const now=Date.parse('2026-10-21T10:20:00Z');
  assert.equal(parseProgress(log,now).stalled,true);
  assert.equal(parseProgress(log+'\n2026-10-21T10:01:00Z INFO Extracting archive',now).stalled,false);
});
test('empty logs do not report completion',()=>{assert.equal(parseProgress('').total,0);assert.equal(parseProgress('').phase,'Initializing node');});
test('actual upstream Unzipping phase cannot trigger a false download-stall warning',()=>{
  const s=parseProgress(log+'\n2026-10-21T10:20:00Z INFO Unzipping snapshot chunk shard-2/chunk_0100.bin',Date.parse('2026-10-21T10:21:00Z'));
  assert.equal(s.phase,'Unpacking snapshot');assert.equal(s.stalled,false);
});
