import test from 'node:test';
import assert from 'node:assert/strict';
import { gates, checkRequest, checkConsent } from '../scripts/write-controls.mjs';
const ready={info:{shardInfos:[{shardId:0,blockDelay:1},{shardId:1,blockDelay:2},{shardId:2,blockDelay:3}]},custody:'0x'+'ab'.repeat(20),storage:1,currentSamples:2};
test('fresh account cannot be connected before sync, registration and storage proof',()=>{
  assert.equal(gates(ready).ready,true);
  for(const change of [{currentSamples:1},{custody:null},{storage:0},{info:{shardInfos:[{blockDelay:1}]}}])assert.equal(gates({...ready,...change}).ready,false);
  assert.equal(gates({...ready,info:{shardInfos:[{shardId:0,blockDelay:1},{shardId:1,blockDelay:25},{shardId:2,blockDelay:2}]}}).ready,false);
});
test('network mutations require explicit approval in the request',()=>{
  for(const body of [{},{approved:false},{approved:'true'}])assert.throws(()=>checkConsent(body));
  assert.doesNotThrow(()=>checkConsent({approved:true}));
});
test('cross-origin, rebound host and missing browser token cannot mutate anything',()=>{
  const good={host:'127.0.0.1:3423',origin:'http://127.0.0.1:3423','x-test-token':'secret','content-type':'application/json'};
  assert.doesNotThrow(()=>checkRequest(good,'secret'));
  for(const change of [{origin:'https://evil.example'},{host:'evil.example'},{'x-test-token':'wrong'},{'content-type':'text/plain'}])assert.throws(()=>checkRequest({...good,...change},'secret'));
});
