import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { buildAction, buildRevocation, buildAuthorization, buildSignedAuthorization, TEST_TEXT } from '../scripts/signing.mjs';
import { sdk } from '../scripts/farcaster-sdk.mjs';
import { privateKeyToAccount } from 'viem/accounts';
const signer = new sdk.NobleEd25519Signer(randomBytes(32));
const context = {fid:1234567,signer};
test('main account and invalid source cannot be used for testing',async()=>{
  for(const fid of [859428,0,-1,NaN]) await assert.rejects(buildAction('post',{...context,fid}),/separate/);
});
test('all six fixed actions have valid cryptographic signatures and exact targets',async()=>{
  for(const action of ['post','follow','like','unfollow','unlike','remove-post']) {
    const message=await buildAction(action,{...context,castHash:'0x'+'ab'.repeat(20)});
    assert.equal((await sdk.validations.validateMessage(message)).isOk(),true,action);
    assert.equal(message.data.fid,context.fid);
    if(action==='post')assert.equal(message.data.castAddBody.text,TEST_TEXT);
    if(action==='follow')assert.equal(message.data.linkBody.targetFid,859428);
    if(action==='like')assert.equal(message.data.reactionBody.targetCastId.fid,859428);
  }
});
test('arbitrary actions and untracked removal targets fail closed',async()=>{
  await assert.rejects(buildAction('transfer',context),/Unsupported/);
  await assert.rejects(buildAction('remove-post',context),/hash/);
});
test('portable tests follow the selected account and like their own recorded post',async()=>{
  const hash='0x'+'cd'.repeat(20),args={...context,followFid:123,likeFid:context.fid,likeHash:hash};
  const follow=await buildAction('follow',args),like=await buildAction('like',args);
  assert.equal(follow.data.linkBody.targetFid,123);
  assert.equal(like.data.reactionBody.targetCastId.fid,context.fid);
  assert.equal(Buffer.from(like.data.reactionBody.targetCastId.hash).toString('hex'),hash.slice(2));
  await assert.rejects(buildAction('like',{...args,likeHash:''}),/Publish/);
});
test('gasless request has only six scopes, one-day sliding TTL and test FID',async()=>{
  const custody=new sdk.ViemLocalEip712Signer(privateKeyToAccount('0x'+randomBytes(32).toString('hex')));
  const message=await buildAuthorization({...context,custody,currentUserNonce:4});
  assert.equal((await sdk.validations.validateMessage(message)).isOk(),true);
  assert.deepEqual([...message.data.keyAddBody.scopes].sort(),[1,2,3,4,5,6]);
  assert.equal(message.data.keyAddBody.ttl,86400);
  assert.equal(message.data.keyAddBody.nonce,5);
});
test('self revocation signs with the key being revoked',async()=>{
  const message=await buildRevocation({...context,requesterNonce:8});
  assert.equal((await sdk.validations.validateMessage(message)).isOk(),true);
  assert.equal(message.data.keyRemoveBody.nonce,9);
  assert.deepEqual(message.data.keyRemoveBody.key,message.signer);
});
test('wallet-returned signatures produce valid authorization; wrong wallet is rejected',async()=>{
  const account=privateKeyToAccount('0x'+randomBytes(32).toString('hex'));
  const key='0x'+Buffer.from((await signer.getSignerKey())._unsafeUnwrap()).toString('hex');
  const deadline=String(sdk.getFarcasterTime()._unsafeUnwrap()+600);
  const request={...sdk.GASLESS_SIGNED_KEY_REQUEST_EIP_712_TYPES,primaryType:'SignedKeyRequest',message:{requestFid:String(context.fid),key,deadline}};
  const authorization={...sdk.GASLESS_KEY_ADD_EIP_712_TYPES,primaryType:'KeyAdd',message:{fid:String(context.fid),key,keyType:1,scopes:[1,2,3,4,5,6],ttl:86400,nonce:1,deadline}};
  const args={...context,custody:account.address,request,authorization,requestSignature:await account.signTypedData(request),authorizationSignature:await account.signTypedData(authorization)};
  const message=await buildSignedAuthorization(args);
  assert.equal((await sdk.validations.validateMessage(message)).isOk(),true);
  await assert.rejects(buildSignedAuthorization({...args,custody:'0x'+'ab'.repeat(20)}),/signature/);
  await assert.rejects(buildSignedAuthorization({...args,authorization:{...authorization,message:{...authorization.message,ttl:90000}}}),/permission/);
});

