import test from 'node:test';
import assert from 'node:assert/strict';
import {waitForAuthorizationReady} from '../scripts/authorization-readiness.mjs';
test('retain signed request while transient readiness recovers; never accept unready state',async()=>{
 let calls=0;const s=await waitForAuthorizationReady(async()=>({ready:++calls===3}),{sleep:async()=>{},attempts:3});assert.equal(s.ready,true);assert.equal(calls,3);
 await assert.rejects(waitForAuthorizationReady(async()=>({ready:false}),{sleep:async()=>{},attempts:3}),/not ready/);
});
