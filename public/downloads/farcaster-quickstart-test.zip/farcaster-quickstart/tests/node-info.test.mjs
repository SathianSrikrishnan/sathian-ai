import test from 'node:test';
import assert from 'node:assert/strict';
import {parseNodeInfo} from '../scripts/node-info.mjs';
test('only exact block-shard unsigned underflow of up to three seconds is bounded',()=>{
 const parse=(shardId,n)=>parseNodeInfo(`{"shardInfos":[{"shardId":${shardId},"blockDelay":${n}}]}`).shardInfos[0];
 assert.equal(parse(0,'18446744073709551615').blockDelay,0);
 assert.equal(parse(0,'18446744073709551613').clockAheadSeconds,3);
 assert.ok(parse(0,'18446744073709551612').blockDelay>10);
 assert.ok(parse(1,'18446744073709551615').blockDelay>10);
 assert.equal(parse(0,'25').blockDelay,25);
});
