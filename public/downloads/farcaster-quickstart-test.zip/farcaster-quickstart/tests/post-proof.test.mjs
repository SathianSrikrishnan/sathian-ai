import test from 'node:test';
import assert from 'node:assert/strict';
import {verifyPostReadback} from '../scripts/post-proof.mjs';
const hash='0x'+'ab'.repeat(20),expected={hash,fid:3356434,text:'test'};
test('independent proof requires exact hash, author and text from both external nodes',async()=>{
 const message={hash,data:{fid:3356434,castAddBody:{text:'test'}}};
 let result=await verifyPostReadback(expected,async()=>({ok:true,json:async()=>message}));assert.equal(result.networkVerified,true);
 result=await verifyPostReadback(expected,async(url)=>({ok:true,json:async()=>url.startsWith('http://127')?message:{...message,hash:'0x'+'cd'.repeat(20)}}));assert.equal(result.localVerified,true);assert.equal(result.networkVerified,false);
});
test('a different isolated account can independently verify its own post',async()=>{
 const message={hash,data:{fid:123,castAddBody:{text:'test'}}};
 const result=await verifyPostReadback({...expected,fid:123},async()=>({ok:true,json:async()=>message}));
 assert.equal(result.localVerified,true);assert.equal(result.networkVerified,true);
});
