import test from 'node:test';
import assert from 'node:assert/strict';
import {selectMetaMask,prepareMetaMask} from '../scripts/wallet-provider.mjs';
test('choose announced MetaMask rather than another default wallet',()=>{
 const mm={request(){}};const phantom={isPhantom:true,isMetaMask:true};
 assert.equal(selectMetaMask([{info:{rdns:'io.metamask'},provider:mm}],phantom),mm);
 assert.throws(()=>selectMetaMask([],phantom),/MetaMask/);
});
test('chain mismatch requests Ethereum and verifies it before continuing',async()=>{
 const calls=[];let chain='0x279f';
 const p={async request(r){calls.push(r.method);if(r.method==='eth_chainId')return chain;if(r.method==='wallet_switchEthereumChain'){assert.equal(r.params[0].chainId,'0x1');chain='0x1';}}};
 await prepareMetaMask(p);assert.deepEqual(calls,['eth_chainId','wallet_switchEthereumChain','eth_chainId']);
});
test('refused chain switch never proceeds to account access or signatures',async()=>{
 const calls=[];const p={async request(r){calls.push(r.method);if(r.method==='eth_chainId')return '0x279f';throw Error('User rejected');}};
 await assert.rejects(prepareMetaMask(p),/User rejected/);assert.equal(calls.includes('eth_signTypedData_v4'),false);
});
