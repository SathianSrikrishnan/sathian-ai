import test from 'node:test';
import assert from 'node:assert/strict';
import { clientState } from '../scripts/client-state.mjs';
test('partial download and unpacking cannot enable a post-reading action',()=>{
  const state=clientState({phase:'Unpacking snapshot',percent:93.5,engine:{running:true},api:null});
  assert.equal(state.canRead,false);assert.match(state.title,/Opening/);assert.match(state.instruction,/No clicks needed/);
});
test('API response enables reading without claiming full synchronization',()=>{
  const state=clientState({phase:'API available',engine:{running:true},api:{version:'0.14.3'}});
  assert.equal(state.canRead,true);assert.match(state.title,/try reading/);
});
test('stopped engine overrides an old API reading',()=>{
  assert.equal(clientState({engine:{running:false},api:{version:'old'}}).canRead,false);
});
