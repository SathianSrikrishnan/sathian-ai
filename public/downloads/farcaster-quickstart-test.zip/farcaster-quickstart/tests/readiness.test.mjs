import test from 'node:test';
import assert from 'node:assert/strict';
import { assess } from '../scripts/readiness.mjs';

const suitable = { cpus: 8, memoryBytes: 32e9, freeDiskBytes: 3.5e12, docker: true, dockerMemoryBytes: 20e9, networkingVerified: true };
test('C-sized free disk cannot qualify despite sufficient host CPU and RAM', () => {
  const result = assess({ ...suitable, freeDiskBytes: 245e9 });
  assert.equal(result.ready, false);
  assert.equal(result.checks.find(c => c.name === 'Selected data disk free space').ok, false);
});
test('stopped engine cannot qualify on otherwise suitable hardware', () => {
  assert.equal(assess({ ...suitable, docker: false }).ready, false);
});
test('host RAM does not substitute for sufficient container allocation', () => {
  assert.equal(assess({ ...suitable, dockerMemoryBytes: 8e9 }).ready, false);
});
test('unverified networking cannot be reported ready', () => {
  assert.equal(assess({ ...suitable, networkingVerified: false }).ready, false);
});
test('all prerequisites verified permits ready status', () => {
  assert.equal(assess(suitable).ready, true);
});
