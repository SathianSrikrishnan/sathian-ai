import test from 'node:test';
import assert from 'node:assert/strict';
import { encodeAbiParameters, parseAbiParameters } from 'viem';
import { fetchCasts } from '../scripts/client-data.mjs';
const message = (key,text) => ({signer:key,hash:'0xabc',data:{fid:37,timestamp:1,castAddBody:{text}}});
const metadata=encodeAbiParameters(parseAbiParameters('(uint256 requestFid, address requestSigner, bytes signature, uint256 deadline)'),[[9152n,'0x1111111111111111111111111111111111111111','0x1234',999999n]]);
const messages=[message('0xaa','legacy'),message('0xbb','gasless'),message('0xcc','unknown')];
const signers=[{key:'0xaa',onChainEvent:{signerEventBody:{metadata:Buffer.from(metadata.slice(2),'hex').toString('base64'),metadataType:1}}},{key:'0xbb',requestFid:123}];
const fetcher=async url=>({ok:true,json:async()=>url.includes('signersByFid')?{signers}:{messages}});
test('origin filtering uses registered requesting app, for legacy and gasless signers',async()=>{
  const a=await fetchCasts('37',fetcher,{mode:'include',app:'9152'});
  assert.deepEqual(a.casts.map(x=>x.text),['legacy']);
  const b=await fetchCasts('37',fetcher,{mode:'include',app:'123'});
  assert.deepEqual(b.casts.map(x=>x.text),['gasless']);
});
test('exclude keeps unknown origins visible and labels them honestly',async()=>{
  const a=await fetchCasts('37',fetcher,{mode:'exclude',app:'9152'});
  assert.deepEqual(a.casts.map(x=>x.text),['gasless','unknown']);
  assert.equal(a.casts[1].appFid,null);
  assert.equal(a.unknownOrigins,1);
});
test('cannot claim filtered results when signer lookup fails',async()=>{
  const a=await fetchCasts('37',async url=>url.includes('signersByFid')?{ok:false,status:500}:fetcher(url),{mode:'include',app:'123'});
  assert.equal(a.ok,false);
});
test('invalid filter is rejected before any network request',async()=>{
  for(const options of [{mode:'include',app:'123&bad=1'},{mode:'other',app:'123'}]) {
    await assert.rejects(()=>fetchCasts('37',()=>assert.fail('unexpected request'),options));
  }
});
