import test from 'node:test';
import assert from 'node:assert/strict';
import {resolveAccount} from '../scripts/account-config.mjs';
test('a new installation must name an isolated account; legacy access is never silently reused',()=>{
  assert.throws(()=>resolveAccount(null,false));
  const fresh=resolveAccount({fid:123,followFid:456},false);
  assert.equal(fresh.fid,123);assert.equal(fresh.relativeDir,'runtime/test-accounts/123');assert.equal(fresh.legacy,false);
  assert.equal(resolveAccount(null,true).relativeDir,'runtime/test-account');
});
test('primary account and same follow target cannot be configured',()=>{
  assert.throws(()=>resolveAccount({fid:859428,followFid:37},false));
  assert.throws(()=>resolveAccount({fid:123,followFid:123},false));
});
