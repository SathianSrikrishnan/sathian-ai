import test from 'node:test';
import assert from 'node:assert/strict';
import {wizardAllowed} from '../scripts/wizard-controls.mjs';
test('only an explicitly approved same-origin wizard request can install or open processes',()=>{
  const h={host:'127.0.0.1:3424',origin:'http://127.0.0.1:3424','x-setup-token':'token','content-type':'application/json'};
  assert.doesNotThrow(()=>wizardAllowed(h,'token',{approved:true}));
  for(const change of [{host:'evil.example'},{origin:'https://sathian.ai'},{'x-setup-token':'other'}])assert.throws(()=>wizardAllowed({...h,...change},'token',{approved:true}));
  assert.throws(()=>wizardAllowed(h,'token',{approved:false}));
});
