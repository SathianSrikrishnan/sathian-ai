# Farcaster Quickstart

Run your own Farcaster server and read posts through your own app.

Start with [QUICKSTART.md](QUICKSTART.md). Windows users can open Start.cmd after extracting the whole archive.

Test build: a complete fresh installation still needs independent verification. Original wrapper MIT; upstream Snapchain GPLv3, downloaded with its separate license. Runtime data, credentials and dependencies are excluded from this source bundle. Never commit runtime/ or recovery phrases.
